import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/Sales_Finance': {
        target: 'https://localhost:7001',
        changeOrigin: true,
        secure: false
      },
      '/Auth': {
        target: 'https://localhost:7001',
        changeOrigin: true,
        secure: false
      }
    }
  }
});
