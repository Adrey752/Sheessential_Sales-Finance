# React + Tailwind proof of concept

This folder is a starter frontend for gradually migrating the current Razor app to React.

## Run

1. Open terminal in `Sheessential_Sales-Finance/frontend`
2. Install deps:

   npm install

3. Start the React app:

   npm run dev

4. Keep the .NET app running too.

## Notes

- Vite proxy points to `https://localhost:7001` for backend requests.
- The sample UI calls:
  - `/Sales_Finance/GetSalesFinanceTables`

## Next step

Migrate one screen at a time (recommended):
- `ExpensesByDepartment` first
- then `Invoices`
- then dashboards/charts
