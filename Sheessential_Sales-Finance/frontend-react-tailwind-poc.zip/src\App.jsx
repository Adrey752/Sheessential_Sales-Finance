import { useEffect, useState } from 'react';

export default function App() {
  const [tables, setTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch('/Sales_Finance/GetSalesFinanceTables');
        if (!res.ok) throw new Error('Failed to load backend data');
        const data = await res.json();
        setTables(data.tables || []);
      } catch (e) {
        setError(e.message || 'Request failed');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  return (
    <main className="min-h-screen p-6">
      <div className="mx-auto max-w-4xl">
        <h1 className="text-3xl font-bold text-brand">Dela Cruz Finance (React + Tailwind)</h1>
        <p className="mt-2 text-sm text-slate-600">Proof of concept frontend connected to your existing .NET backend.</p>

        <section className="mt-6 rounded-2xl border bg-white p-5 shadow-sm">
          <h2 className="text-lg font-semibold">SalesAndFinanceDB tables</h2>

          {loading && <p className="mt-3 text-sm text-slate-500">Loading...</p>}
          {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

          {!loading && !error && (
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {tables.map((t) => (
                <li key={t} className="rounded-lg border bg-slate-50 px-3 py-2 text-sm">
                  {t}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </main>
  );
}
